# FJGO - Finder Job Gae One
App per la ricerca lavoro remota per categorie protette.